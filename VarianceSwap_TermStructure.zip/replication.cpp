#include "replication.hpp"


replication::replication()
{
}


void replication::calcTS() {
	// Data from "A Guide to Volatility and Variance Swaps"
	// Derman, Kamal & Zou, 1999
	// with maturity t corrected from 0.25 to 0.246575
	// corresponding to Jan 1, 1999 to Apr 1, 1999
	value = {
		Position::Long,		// type
		0.04,				// variance strike
		50000,				// nominal
		100.0,				// spot
		0.00,				// dividend
		0.05,				// risk-free rate
		0.246575,			// time to maturity
		0.20,				// volatility
		0.04189,			// result
		1.0e-4				// tolerance
	};
	// Expected variance swap result
	expected = value.result;

	// Data from "A Guide to Volatility and Variance Swaps"
	// Derman, Kamal & Zou, 1999
	replicatingOptionData = {
		//Option::Type, strike, vol
		{ Option::Put,   50,  0.30 },
		{ Option::Put,   55,  0.29 },
		{ Option::Put,   60,  0.28 },
		{ Option::Put,   65,  0.27 },
		{ Option::Put,   70,  0.26 },
		{ Option::Put,   75,  0.25 },
		{ Option::Put,   80,  0.24 },
		{ Option::Put,   85,  0.23 },
		{ Option::Put,   90,  0.22 },
		{ Option::Put,   95,  0.21 },
		{ Option::Put,  100,  0.20 },
		{ Option::Call, 100,  0.20 },
		{ Option::Call, 105,  0.19 },
		{ Option::Call, 110,  0.18 },
		{ Option::Call, 115,  0.17 },
		{ Option::Call, 120,  0.16 },
		{ Option::Call, 125,  0.15 },
		{ Option::Call, 130,  0.14 },
		{ Option::Call, 135,  0.13 }
	};

	interestRates = {
		// date,				interest rate
		{ today,				0.05 },
		{ today + 1 * Days,		0.05 },
		{ today + 1 * Weeks,	0.05 },
		{ today + 1 * Months,	0.05 },
		{ today + 2 * Months,	0.05 },
		{ today + 3 * Months,	0.05 },
		{ today + 4 * Months,	0.05 },
		{ today + 7 * Months,	0.05 },
		{ today + 10 * Months,	0.05 },
		{ today + 13 * Months,	0.05 },
		{ today + 16 * Months,	0.05 },
		{ today + 19 * Months,	0.05 },
		{ today + 22 * Months,	0.05 },
		{ today + 25 * Months,	0.05 },
		{ today + 28 * Months,	0.05 },
		{ today + 31 * Months,	0.05 },
		{ today + 34 * Months,	0.05 },
		{ today + 37 * Months,	0.05 },
		{ today + 40 * Months,	0.05 },
		{ today + 43 * Months,	0.05 },
		{ today + 46 * Months,	0.05 },
		{ today + 4 * Years,	0.05 },
		{ today + 5 * Years,	0.05 },
		{ today + 6 * Years,	0.05 },
		{ today + 7 * Years,	0.05 },
		{ today + 8 * Years,	0.05 },
		{ today + 9 * Years,	0.05 },
		{ today + 10 * Years,	0.05 },
		{ today + 11 * Years,	0.05 },
		{ today + 12 * Years,	0.05 },
		{ today + 13 * Years,	0.05 },
		{ today + 14 * Years,	0.05 }
	};

	// IRDates and IR vectors
	for (auto ir : interestRates) {
		IRDates.emplace_back(ir.date);
		IR.emplace_back(ir.rate);
	}

	// Exercise date
	exDate = today + Integer(value.t * 365 + 0.5);
	// Stupid BlackVarianceSurface() function only accepts Matrix-type
	dates = { exDate };

	// Here we assume ascending strikes, with the min-call strike == max-put strike
	for (auto replicatingOptionDatum : replicatingOptionData) {
		// Call option
		if (replicatingOptionDatum.type == Option::Call) {
			callStrikes.emplace_back(replicatingOptionDatum.strike);
			callVols.emplace_back(replicatingOptionDatum.v);
		}
		// Put option
		else if (replicatingOptionDatum.type == Option::Put) {
			putStrikes.emplace_back(replicatingOptionDatum.strike);
			putVols.emplace_back(replicatingOptionDatum.v);
		}
		// Return error
		else {
			QL_FAIL("Unknown option type!");
		}
	}// end of for-replicatingOptionData

	 // BlackVarianceSurface() function only accepts Matrix-type vols
	 // Notice there is 1` duplication between call and put strikes
	Matrix vols(replicatingOptionData.size() - 1, 1);

	// Store all strikes & vols (put & call) in ascending order
	//// Step 1: put option & vols
	for (size_t i = 0; i < putVols.size(); i++) {
		vols[i][0] = putVols[i];
		strikes.emplace_back(putStrikes[i]);
	}
	//// Step 2: call option & vols
	//// must start from 1 since callOption[0] == putOption[last]
	for (size_t i = 1; i < callVols.size(); i++) {
		vols[i + putVols.size() - 1][0] = callVols[i];
		strikes.emplace_back(callStrikes[i]);
	}

	// Build BlackVarianceSurface()
	boost::shared_ptr<BlackVolTermStructure> volTS(new
		BlackVarianceSurface(today, NullCalendar(), dates, strikes, vols, dc));

	// Build BlackScholesMertonProcess()
	boost::shared_ptr<GeneralizedBlackScholesProcess> stochProcess(new
		BlackScholesMertonProcess(
			Handle<Quote>(boost::shared_ptr<Quote>(new SimpleQuote(value.s))),
			Handle<YieldTermStructure>(boost::shared_ptr<YieldTermStructure>(new
				FlatForward(today, value.q, dc))),
			Handle<YieldTermStructure>(boost::shared_ptr<YieldTermStructure>(new
				InterpolatedZeroCurve<ForwardFlat>(IRDates, IR, dc, Calendar(), ForwardFlat()))),
			Handle<BlackVolTermStructure>(volTS)
		)
	);

	// Build Pricing Engine
	boost::shared_ptr<PricingEngine> engine(new
		ReplicatingVarianceSwapEngine(
			stochProcess,	//BlackScholesMertonProcess
			5.0,			// dK
			callStrikes,
			putStrikes));

	// Call VarianceSwap class, then Set Pricing Engine
	VarianceSwap varianceSwap(value.type,
		value.varStrike,
		value.nominal,
		today,
		exDate);
	varianceSwap.setPricingEngine(engine);

	// Output
	calculated = varianceSwap.variance();
	error = std::fabs(calculated - expected);
	std::cout << "Expected: " << expected << ", Calculated: " << calculated
		<< ", Error: " << error << std::endl;
}


replication::~replication()
{
}
