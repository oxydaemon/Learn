#pragma once
#include <iostream>
#include <ql\quantlib.hpp>
#include <vector>
using namespace QuantLib;


class replication {
private:
	struct ReplicatingVarianceSwapData {
		Position::Type type;
		Real varStrike;
		Real nominal;
		Real s;         // spot
		Rate q;         // dividend
		Rate r;         // risk-free rate
		Time t;         // time to maturity
		Volatility v;   // volatility at t
		Real result;    // result
		Real tol;       // tolerance
	};

	struct VolData {
		Option::Type type;
		Real strike;
		Volatility v;
	};

	struct DivData {
		Date date;
		Spread dividend;
	};

	struct IRData {
		Date date;
		Rate rate;
	};

	ReplicatingVarianceSwapData value;
	std::vector<VolData> replicatingOptionData;
	std::vector<IRData> interestRates;

	// Day count
	DayCounter dc = Actual365Fixed();
	Date today = Date(23, February, 2017);

	// IRDates and IR vectors
	std::vector<Date> IRDates;
	std::vector<Rate> IR;

	// Exercise date
	Date exDate;
	// Stupid BlackVarianceSurface() function only accepts Matrix-type
	std::vector<Date> dates;

	// Initialize callStrikes, putStrikes, callVols, and putVols vector
	std::vector<Real> callStrikes;
	std::vector<Real> putStrikes;
	std::vector<Real> callVols;
	std::vector<Real> putVols;
	// Store all strikes (put & call) in order
	std::vector<Real> strikes;

	// Output
	Real calculated;
	Real expected;
	Real error;

public:
	replication();
	void calcTS();
	~replication();
};

