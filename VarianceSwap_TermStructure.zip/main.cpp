#include "replication.hpp"

int main() {
	replication Rep;
	Rep.calcTS();

	system("pause");
	return 0;
}